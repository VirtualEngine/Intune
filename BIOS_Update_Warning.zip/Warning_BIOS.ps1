﻿$Global:Current_Folder = split-path $MyInvocation.MyCommand.Path

[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')  				| out-null
[System.Reflection.Assembly]::LoadWithPartialName('presentationframework') 				| out-null
[System.Reflection.Assembly]::LoadFrom("$Current_Folder\assembly\MahApps.Metro.dll")       				| out-null
[System.Reflection.Assembly]::LoadFrom("$Current_Folder\assembly\MahApps.Metro.IconPacks.dll")      | out-null  

function LoadXml ($global:filename)
{
	$XamlLoader=(New-Object System.Xml.XmlDocument)
	$XamlLoader.Load($filename)
	return $XamlLoader
}

$XamlMainWindow=LoadXml("$Current_Folder\Warning_BIOS.xaml")

$Reader=(New-Object System.Xml.XmlNodeReader $XamlMainWindow)
$Form=[Windows.Markup.XamlReader]::Load($Reader)

$Main_Title = $Form.findname("Main_Title") 
$Part1 = $Form.findname("Part1") 
$Part2 = $Form.findname("Part2") 
$Part3 = $Form.findname("Part3") 
$Part4 = $Form.findname("Part4") 
$Next_Button = $Form.findname("Next_Button")
$Defer_Button = $Form.findname("Defer_Button") 
$Previous_Button = $Form.findname("Previous_Button") 
$Main_Buttons = $Form.findname("Main_Buttons") 
$FlipView = $Form.findname("FlipView") 
$Documentation_Part = $Form.findname("Documentation_Part") 

$FlipView.IsBannerEnabled = $false
$FlipView.IsNavigationEnabled = $false
$FlipView.LeftTransition = 0


$Main_Buttons.Margin = "44,0,0,0"

$FlipView.Add_SelectionChanged({
	Switch ($FlipView.SelectedIndex) 
		{ 
			0 
			{   		
				$Part1.Background="#00AF89"
				$Part1.BorderBrush="#00AF89"
				
				$Part2.Background="#D4D4D4"
				$Part2.BorderBrush="#D4D4D4"

				$Previous_Button.Content = "Previous"
                $Defer_Button.Content = "Defer until tomorrow"
				$Next_Button.Content = "Next"				
				$Previous_Button.Visibility = "Collapsed"
                $Defer_Button.Visibility = "Visible"	

				$Main_Buttons.Margin = "-107,0,0,0"				
			}

			1 
			{ 
				$Part1.Background="#D4D4D4"
				$Part1.BorderBrush="#D4D4D4"
				
				$Part2.Background="#00AF89"
				$Part2.BorderBrush="#00AF89"

				$Previous_Button.Content = "Previous"
				$Next_Button.Content = "Next"				
				$Previous_Button.Visibility = "Visible"
                $Defer_Button.Visibility = "Collapsed"

				$Main_Buttons.Margin = "-107,0,0,0"									
			} 			

		} 	
})			
		

$Next_Button.Add_Click({
	If(($FlipView.SelectedIndex) -eq 0)
		{
			If((gwmi -Class Win32_Battery).BatteryStatus -ne 2)
				{
					[MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Battery warning","Your device is running on battery.`nPlease connect the AC adapter to your PC to start the update.")				
				}
			Else
				{
					($FlipView.SelectedIndex) = 1
				}
			
		}
	ElseIf(($FlipView.SelectedIndex) -eq 1)
		{			
			$okAndCancel = [MahApps.Metro.Controls.Dialogs.MessageDialogStyle]::AffirmativeAndNegative  
			$Button_Style = [MahApps.Metro.Controls.Dialogs.MetroDialogSettings]::new()
			$Button_Style.AffirmativeButtonText = "Update and restart"
			$Button_Style.NegativeButtonText = "Defer until tomorrow"		
			$result = [MahApps.Metro.Controls.Dialogs.DialogManager]::ShowModalMessageExternal($Form,"Restart required","A restart of your device is required to finalise the process.`n`nBy clicking on « Update and restart  » your computer will restart in the next 5 minutes.`n`nDo not forget to save your work before clicking on Restart !",$okAndCancel, $Button_Style)   

			If($result -eq "Affirmative")
				{
					$Get_Current_Model = ((gwmi win32_computersystem).Model).Substring(0,4)
					$BIOS_Update_Folder = "$env:temp\BIOSUpdate_$Get_Current_Model"
					$User_Continue_Process_File = "$BIOS_Update_Folder\BIOS_Update_Continue.txt"
					new-item $User_Continue_Process_File -Type File				
					$Form.Close()			
				}
            else {
            
                $Form.Close()

            }		
		}
})		


$Previous_Button.Add_Click({
	If(($FlipView.SelectedIndex) -eq 2)
		{
			($FlipView.SelectedIndex) = 1
		}
	ElseIf(($FlipView.SelectedIndex) -eq 1)
		{
			($FlipView.SelectedIndex) = 0
		}
})

$Defer_Button.Add_Click({

    $Form.Close()
})

			

$Form.ShowDialog() | Out-Null